/* 42.	Create a class Tile to store the edge length of a square tile, and create another class Floor to store length and width of a rectangular floor.
 Add method totalTiles(Tile t) in Floor class with Tile as argument to calculate the whole number of tiles needed to cover the floor completely.
 */
 
 class Tile{
	int length;
	Tile(int len)
	{
		length = len;
	}
}

class Floor{
	static  int length;
	static int width;
	Floor(int len , int wt)
	{
		length = len;
		width = wt;
	}
	static double totalTile(Tile T) {
		int tileLength = T.length;
		int tileArea = tileLength*tileLength;
		int floorArea = length*width;
		double tileRequire = (double) floorArea/tileArea;
		return tileRequire;
	}
	
}

public class Q42_TileDemo{
	public static void main(String[] args)
	{
		Tile T1 = new Tile(25);
		Floor F = new Floor(150,180);
		double total = Floor.totalTile(T1);
		System.out.println("Total Tiles Required are " + total + " Tiles");
	}
}