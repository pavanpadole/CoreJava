class foo
{
	foo()
	{
		this(10);
		System.out.println("Normal costructer call");
	}
	foo(int i)
	{
		System.out.println("Parameterized costructer call");
	}
}

class Q41_ThisConstruct
{
	public static void main(String args[])
	{
	foo f=new foo();
    }
}
