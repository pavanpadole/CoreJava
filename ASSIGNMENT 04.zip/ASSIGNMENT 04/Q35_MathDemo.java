/* 35.Create a class MathOperation that has four static methods. add() method that takes two integer numbers as parameter
 and returns the sum of the numbers. subtract() method that takes two integer numbers as parameter and returns the 
difference of the numbers. multiply() method that takes two integer numbers as parameter and returns the product. 
power() method that takes two integer numbers as parameter and returns the power of first number to second number.
Create another class Demo (main class) that takes the two numbers from the user and calls all four methods of MathOperation 
class by providing entered numbers and prints the return values of every method.
*/

import java.lang.Math;
import java.util.Scanner;
class Mathoperation{
	static int add(int a,int b)
	{
		int sum=a+b;
		return sum;

	}
	
	static int subtract(int a,int b)
	{
		int sub=a-b;
		return sub;
	}

	static int multiply(int a,int b)
	{
		int mul=a*b;

		return mul;
	}

	static double power(int a,int b)
	{
		double result = Math.pow(a, b);

		return result;
	} 
}

class Q35_MathDemo{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter first number");
		int first=sc.nextInt();

		System.out.println("Enter second number");
		int second=sc.nextInt();
	
	int addition=Mathoperation.add(first,second);
	System.out.println("Addition of two number :" +addition);

	int sub=Mathoperation.subtract(first,second);
	System.out.println("Substraction of two number :" +sub);

	int mul=Mathoperation.multiply(first,second);
	System.out.println("Multiplication of two number :" +mul);

	double power=Mathoperation.power(first,second);
	System.out.println("Power is :" +power);
	

	}

}