/*  40.	Create a class Student having data members name, roll no., age and score. 
Write a program to accept 10 records of student and store them in an array. 
And then arrange the student records based on the score group [0-50], [50-65], [65-80], [80-100].
*/

import java.util.*;
import java.lang.*;
	class Student{
		String name;
		int rollno , age , score;
		
		Student(String name , int age , int rollno , int score)
		{
			this.name = name;
			this.age = age;
			this.rollno = rollno;
			this.score = score;
		}
	
		@Override
		public String toString() {
			return "Student [name=" + name + ", rollno=" + rollno + ", age=" + age + ", score=" + score + "]";
		}
		
	}
	
	public class Q40_Student {
		public static void main(String[] args)
		{
			Scanner sc=new Scanner(System.in);
		Student[] persons = new Student[10];
		
		for(int i=0 ; i < persons.length ;i++)
		{
			String name=sc.nextLine();
			int age = (int) Math.round((Math.random()*(40-20)+20)); // Range 40-20
			int rollno = i+40;
			int score = (int) Math.round((Math.random()*100));
			Student S = new Student(name,age,rollno,score);
			persons[i] = S;	
		}
		
		// Arrange Student as Per Records :-  so makeing List as per Score
		List<Student> arr0_50 = new ArrayList<Student>();
		List<Student> arr50_65 = new ArrayList<Student>();
		List<Student> arr65_80 = new ArrayList<Student>();
		List<Student> arr80_100 = new ArrayList<Student>();
		
		for(Student person: persons)
		{
			if(person.score<=50)
				arr0_50.add(person);
			else if(person.score<=65 && person.score >50)
				arr50_65.add(person);
			else if(person.score <=80 && person.score >65)
				arr65_80.add(person);
			else
				arr80_100.add(person);	
		}
		
		System.out.println("List of Students Have Score 0-50 " + arr0_50);
		System.out.println("List of Students Have Score 0-50 " + arr50_65);
		System.out.println("List of Students Have Score 0-50 " + arr65_80);
		System.out.println("List of Students Have Score 0-50 " + arr80_100);	
	}
		
	}