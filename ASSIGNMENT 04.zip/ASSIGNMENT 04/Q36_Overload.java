/*36.Create a class MathOperation containing overloaded methods ‘multiply’ to calculate multiplication of following arguments. 
a. two integers 
b. three floats 
c. all elements of array 
d. one double and one integer */

class MathOperation{
	static void multiply(int a,int b)
	{
	int mul=a*b;
	System.out.println("Multiplication of integer type :"+mul);
	}

	static void multiply(float a,float b,float c)
	{
	float mul=a*b*c;
	System.out.println("Multiplication of float type :"+mul);
	}

	static void multiply(int[] arr)
	{
	
	int m=1;
	for(int i=0; i<arr.length;i++)
	{
	 m=arr[i]*m;
	}
		System.out.println("Multiplication of Array  :"+m);
	
	}

	static void multiply(double a,int b)
	{
	double mul=a*b;
	System.out.println("Multiplication of double  :"+mul);
	}
}

class Q36_Overload{
	public static void main(String args[])
	{
	//int arr[]= new int[5];
	int arr[]={2,5,3,2,1};
	MathOperation.multiply(2,3);
	

	MathOperation.multiply(2,3,4);

	MathOperation.multiply(arr);
	
	MathOperation.multiply(2.3,3);
	
	}
}
