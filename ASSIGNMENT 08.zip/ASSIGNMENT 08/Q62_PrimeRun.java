import java.io.*;
import java.util.*;

class Prime implements Runnable
{
		private int no;
		Prime(int no){
			this.no=no;
					}
    public void run()
    {
       
            int cnt=0;
            for(int i=2;i<=no/2;i++)
                if(no%i==0)
                {
                    cnt++;
                    break;
                }
            if(cnt==0) {
                System.out.println(no+" Number is prime");
            }else {
            System.out.println("Not Prime Number");
            }
      }
    
}

public class Q62_PrimeRun{

	    public static void main(String args[])
	    {
			
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter the Number :");
			int i=sc.nextInt();
	        try
	        {
	           
	            Prime p1=new Prime(i);
	            Thread t1=new Thread(p1);
	            
	            t1.start();
	        }
	        catch(Exception e1){}
	    }
}