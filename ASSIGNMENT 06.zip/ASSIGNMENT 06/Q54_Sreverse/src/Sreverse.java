
//54.	Write a program to reverse the given String.
//import java.lang.*;
public class Sreverse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s= "Heyy HIIIi you know Me I Am from vasmat";
		  String reverse = new StringBuffer(s).reverse().toString();
		  String reverseBuid =new StringBuilder(s).reverse().toString();
		  System.out.println("Reverse string is using String Buffer :" + reverse);
		  
		  System.out.println("Reverse string is using String builder :" + reverseBuid);
	}

}