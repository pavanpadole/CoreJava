
public class Wreverse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="hii only ";
		char a[]=s.toCharArray();
		
		int f=0;
		int l=0;
		
		for(int i=0;i<a.length;i++)
		{
			l=(a[i]==' ')?i-1:i;
			
			while(f>l)
			{
				char temp=a[i];
				a[l]=a[f];
				a[f]=temp;
				
				l--;
				f++;
			}
			f=i+1;
		}
		System.out.println(new String (a));
	}
	
}
