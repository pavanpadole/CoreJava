//56.	Write a program to convert very first character of every word in upper case in a String.

import java.util.Scanner;
public class Q56_FUppercase {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//String s="I am one of them that never give up and its my real POWER";
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter statment :");
		String s=sc.nextLine();
		
		char ar[]=s.toCharArray();
		
		boolean first=true;
		
		for(int i=0;i<ar.length;i++)
		{
			if(ar[i]==' ')
			{
				first=true;
				continue;
			}
			if(first)
			{
				if(ar[i]>=97 && ar[i]<=122)
				{
					ar[i]-=32;
					
				}
			}
			first=false;
		}
		System.out.println(new String(ar));
		//sc.close();
	}

}
