//55.	Write a program to count no of words in the String.
public class Slength {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="I am one of them that never give up and its my real POWER";
		int len=s.length();
		System.out.println("Lenth of string is :" +len);
		
		String up=s.toUpperCase();
		System.out.println("Lenth of string is :" +up);
	}

}
