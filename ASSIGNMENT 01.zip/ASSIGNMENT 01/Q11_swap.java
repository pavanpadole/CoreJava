
import java.util.Scanner;
class Q11_swap{
	public static void main(String args[])
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter two number :");
		int first=sc.nextInt();
		int second=sc.nextInt();
		
		System.out.println("Before swap : First no:" +first+ "  Second No:" +second);

		first=first*second;
		second=first/second;
		first=first/second;

		System.out.println("After swap : First No: "+first+ "  Second No:"+second );
	}
}