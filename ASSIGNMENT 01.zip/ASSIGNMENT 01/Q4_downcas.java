import java.util.*;
class Q4_downcas{
	public static void main(String args[])
	{
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter the value of A :");
	byte a= sc.nextByte();

	System.out.println("Enter the value of B :");
	byte b= sc.nextByte();

	byte c=(byte) (a+b);
	System.out.println("Sum = "+c);

	}
}
	
	