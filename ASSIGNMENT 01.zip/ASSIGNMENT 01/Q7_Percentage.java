import java.util.Scanner;
class Q7_Percentage{
	public static void main(String args[])
	{
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter 5 subject marks");
	System.out.println("Mark of first Subject");
	int m1=sc.nextInt();

	System.out.println("Mark of second Subject");
	int m2=sc.nextInt();

	System.out.println("Mark of 3rd Subject");
	int m3=sc.nextInt();

	System.out.println("Mark of 4th Subject");
	int m4=sc.nextInt();

	System.out.println("Mark of 5th Subject");
	int m5=sc.nextInt();

	int Marks=m1+m2+m3+m4+m5;
	double percentage = (Marks/500.0)*100;

	//System.out.println("total =" +Marks);
	System.out.println("Percentage =" +percentage);
	}
}