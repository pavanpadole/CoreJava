class Q3_primitiveDT{
	public static void main(String args[])
	{
	int x=10;
	int y;
//A
	System.out.println("A.Given expression is : y = x2 + 3x - 7 ");
	y=(x*x) + 3*x - 7;
	System.out.println("A.Value of y :"+y);
	
//B	
	System.out.println(" B.Given expression is :y=x++ + ++x");
	y=x++ + ++x;
	System.out.println("B.Value of y :"+y);
	
	System.out.println("B.Value of x :"+x);
	
//C
	System.out.println("C.Given expression is : z = x++ - --y - --x  +  x++");
	int z;
	z = x++ - --y - --x  +  x++ ;
	System.out.println("C.Value of x :"+x);
	
	System.out.println("C.Value of y :"+y);
	
	System.out.println("C.Value of Z :"+z);
	
//D
	System.out.println(" D.Given expression is : z1 = x1 && y1 || !(x1 || y1) ");
	boolean x1=true;
	boolean y1=true;
	boolean z1 = x1 && y1 || !(x1 || y1) ; 
	System.out.println("C.Value of Z :"+z1);
	
	}
}