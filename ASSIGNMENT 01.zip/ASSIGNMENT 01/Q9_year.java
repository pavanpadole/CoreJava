//09.	Write a program to read the days (eg. 670 days) as integer value using Scanner class.
// Now convert the entered days into complete years, months and days and print them.

import java.util.Scanner;
class Q9_year{ 
    public static void main(String args[])
    {
        int days, year, week, day;
        Scanner sc = new Scanner(System.in);
        System.out.print("Please enter the number of days:");
        days = sc.nextInt();
        year = days / 365;
        days = days % 365;
        System.out.println("Number of years:"+year);
        week = days / 7;
        days = days % 7;
        System.out.println("Number of weeks:"+week);
        day = days;
        System.out.println("Number of days:"+day);
    }
}