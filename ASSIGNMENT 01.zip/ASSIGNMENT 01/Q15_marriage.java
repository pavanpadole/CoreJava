//15.	Accept person’s gender (character m for male and f for female), age (integer), as input and then check whether person is eligible for marriage or not.
import java.util.Scanner;
class Q15_marriage{
	public static void main(String args[])
	{
	Scanner sc=new Scanner(System.in);
	System.out.println(" please enter Gender m or f  ");
	char gender =sc.next().charAt(0);

	System.out.println(" please enter Age ");
	int age =sc.nextInt();

	if(gender== 'm' && age >= 21)
	{
	System.out.println("person is eligible for marriage ");
	}
	else if(gender=='f' && age >= 18)
	{
	System.out.println("person is eligible for marriage ");
	}
	else
	{
	System.out.println("person is Not eligible for marriage");
	}
}
}