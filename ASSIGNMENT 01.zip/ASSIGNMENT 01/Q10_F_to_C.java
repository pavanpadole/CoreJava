//10.	Write a program to convert temperature from Fahrenheit to Celsius. 
//	Take Fahrenheit as input using Scanner class. [ formula : C= 5*(f-32)/9 ]

import java.util.Scanner;
class Q10_F_to_C{
	public static void main(String args[])
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the Fahrenheit temperature :");
		double f=sc.nextDouble();

		double celsius= 5*(f-32)/9;
		System.out.println("Convesion of Fahrenheit to Celsius :" +celsius);
	}
}