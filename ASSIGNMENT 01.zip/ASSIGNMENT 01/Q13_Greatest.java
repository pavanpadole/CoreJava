//13.	Program to find greatest in 3 numbers. [ once using if else statement and then using ternary operator ( logical operator) ]  

import java.util.Scanner;
import java.lang.*;
class Q13_Greatest{
	public static void main(String args[])
	{
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the Three number :");
	System.out.println("1st Number");
	int first=sc.nextInt();

	System.out.println("2nd Number");
	int second=sc.nextInt();

	System.out.println("3rd Number");
	int third=sc.nextInt();

	if(first > second && first > third)
	{
	System.out.println(" Greatest Number is =" +first);
	}
	else if(second > first && second >third)
	{
	System.out.println("Greatest Number is =" +second);
	}
	else
	{
	System.out.println("Greatest Number is =" +third);
	}

//Ternary Opertor:
	System.out.println("USING TERNARY OPERTOR");
	String s=(first > second && first > third) ? first+" Is gretest" :(second > first && second > third) ? second+ " is greatest" : third+ " is greatest";
	System.out.println(s);
}
}
	