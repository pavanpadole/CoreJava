import java.util.Scanner;
class Q6_circle{
	public static void main(String args[])
	{
	Scanner sc=new Scanner(System.in);
	System.out.println("Please enter a Radius");
	int r=sc.nextInt();
	
	double Area=3.14*r*r;
	double Circumference=2*3.14*r;

	System.out.println("Area of Circle =" +Area);
	System.out.println("Circumference of Circle =" +Circumference);
	}
}