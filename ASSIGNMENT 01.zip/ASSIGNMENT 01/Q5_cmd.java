import java.util.*;

class Q5_cmd{

    public static void main(String args[]) {
        
        String name = args[0];
        System.out.println("Welcome "+name);
        
    }
}

//javac Q5_cmd.java
//java Q5_cmd Pavan