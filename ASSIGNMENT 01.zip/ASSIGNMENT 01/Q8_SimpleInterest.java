//08.	Write a program to find the simple interest. Take the principle amount, rate of interest and time from user using Scanner class.

import java.util.Scanner;
class Q8_SimpleInterest{
	public static void main(String args[])
	{
	Scanner sc=new Scanner(System.in);
	System.out.println("please enter the principle amount");
	int PA=sc.nextInt();
	
	System.out.println("please enter the rate");
	int R=sc.nextInt();
	
	System.out.println("please enter the Time");
	int t=sc.nextInt();
	
	Double SI=(PA*R*t) / 100.0;

	System.out.println("Simple Interest is =" +SI);
}
}
	