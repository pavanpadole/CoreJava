class Q_1_helloword{
	public static void main(String args[])
	{
	System.out.println("Hello World");
	}
}