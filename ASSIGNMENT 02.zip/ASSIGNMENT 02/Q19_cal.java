//19.	Calculate  series : 12+22+32+42+.........+n2
import java.util.Scanner;
class Q19_cal{
	public static void main(String args[])
	{
	Scanner sc= new Scanner(System.in);
	System.out.println("How many number in series :");
	int no=sc.nextInt();
	
	int res=12;
	int sum=0;
	for(int i=1;i<no;i++)
	{
	System.out.print(res+"  ");
	res=res+10;
	sum=sum+res;
        System.out.println(res+"  ");
	
	}
	System.out.println(" ");
	System.out.println(" Sum of series :"+sum);
	}
	}

	