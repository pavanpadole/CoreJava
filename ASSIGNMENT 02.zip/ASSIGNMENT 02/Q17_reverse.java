import java.util.Scanner;
class Q17_reverse{
	public static void main(String args[])
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("number");
		int no=sc.nextInt();
		int reverse=0;

	while(no!=0)
	{
		int dig=no%10;
		reverse=reverse * 10+dig;
		no=no/10;
	}
	System.out.println(reverse);
}
}