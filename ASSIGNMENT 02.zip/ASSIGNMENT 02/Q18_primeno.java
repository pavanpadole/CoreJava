//18.	Program to check whether number is prime or not.
//import java.util.Scanner;
class Q18_primeno{
	public static void main(String args[])
	{
	int no=8;
	boolean flag=true;

	for(int i=2;i<no;i++)
	{
	if(no%i==0)
	{
	System.out.println("Not a prime number");
	flag=false;
	break;
	}
}	
	if(flag)
	{
	System.out.println("prime number");
	}
}
}