//21.	Program to show sum and average of 10 element array. Accept array elements from user. 

import java.util.Scanner;
class Q21_Average{
	public static void main(String args[])
	{
	int sum=0;
	//int len=10;

	Scanner sc= new Scanner(System.in);	
	int arr[]=new int[10];
	
	System.out.println(" enter the 10 number");
	for(int i=0;i<arr.length;i++)
	{
	System.out.println("enter number " +(i+1)  );
	arr[i]= sc.nextInt();
	}

	for(int k:arr)
	{
	sum=sum+k;
	}

	System.out.println("sum = " +sum);
	System.out.println("Average = " +sum/(arr.length));
	}
	}
