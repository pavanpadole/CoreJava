/* 25.	Write the program to find the sum of even elements and sum of odd elements present in the array of integer type.
*/

class Q25_SumOfEv
{
	public static void main(String args[])
	{
		int arr[] = {10,20,15,4,13,1};
		int sumEv=0 , sumOdd=0;
		for(int i=0; i<arr.length; i++)
		{
			if(arr[i]%2==0)
			{
				sumEv = sumEv+arr[i];
			}
			else
			{
				sumOdd = sumOdd + arr[i];
			}
		}
		System.out.println("Sum of Even number : "+sumEv);
		System.out.println("Sum of Odd number : "+sumOdd);
	}
}