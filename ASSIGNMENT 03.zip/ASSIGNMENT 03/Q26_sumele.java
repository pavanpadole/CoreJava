import java.util.Scanner;
class Q26_sumele{
	public static void main(String args[])
	{
	int sum=0;
	int a[]={1,2,3,4};
	int b[]={5,6,7,8};
	int c[]={11,12,13,14};
	int d[]={16,17,18,19};
	int e[]={77};

	int arr[][]=new int[5][];

	arr[0]=a;
	arr[1]=b;
	arr[2]=c;
	arr[3]=d;
	arr[4]=e;

	for(int i=0;i<5;i++)
	{
	for(int j :arr[i])
		{
		System.out.print("  "+j);
		sum=sum+j;
		}
		System.out.println("  ");
	}
	System.out.println("Sum of all element :" +sum);

	}
}