//27.	Write a program to fine the smallest and greatest number present in the array of integer type.

import java.util.Scanner;
class Q27_Greatest{
	public static void main(String args[])
	{
	

	Scanner sc=new Scanner(System.in);
	int arr[]=new int[5];
	System.out.println("Enter element :");
	for(int i=0;i<arr.length;i++)
		{

		arr[i]=sc.nextInt();
		}
	
	int max=arr[0];
	int min=arr[0];	

	for(int j:arr)
	//for(int i=0;i<5;i++)
	{
		if(j>max)
	{
		max=j;
	
		//System.out.println(" "+j);
	}
		
		if(j<min)
	{
		min=j;
	}
	
	}
	System.out.println("Gretest number in array is:  "+max);
	System.out.println("Smallest number in array is:  "+min);
	}
}
	 