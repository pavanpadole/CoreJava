// 28.	Initialize one String type of array and print the elements using for each loop.

import java.util.Scanner;
class Q28_ForEach
{
	public static void main(String[] args)
	{
	String arr[]={"pavan","Parikshit","raj","vasmat","C-DAC Mumbai"};
	
	System.out.println("Using normal for loop :");
	for(int i=0; i<arr.length;i++)
	{
		System.out.println("Heyyy Helloooo " +arr[i]);
	}
	
	System.out.println("Using for each loop :");
	for(String a:arr)
	{
		System.out.println("hiii  :" +a);
	}
	
}
}
