
 class Voter{
	int id;
	String name;
	byte age;
	
	public Voter(int id, String name, byte age) throws Exception {
		if(age>18) {
			this.id = id;
			this.name = name;
			this.age = age;
			System.out.println("Voter Acess Granted");
		} else
			throw new Exception();
		
	}
	
}

public class Q59_VoterDemo{
			
			public static void main(String[] args){
		
			try {
				Voter v1 = new Voter(20063,"pvn",(byte)16);
			} catch (Exception e) {
				System.out.println("SORRY : Invalid Age For Voter");
			}
			
			}
		}