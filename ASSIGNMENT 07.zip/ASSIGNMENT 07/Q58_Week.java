

import java.util.*;
public class Q58_Week{
			
			public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
		
				String[] arr = {"Sun","Mon","Thues","Wed","Thurs","Fri","Satur"};
				
				Scanner scan = new Scanner(System.in);
				System.out.println("Enter WeekDay from 0-6 : ");
				int num = scan.nextInt();
				try {
					System.out.println("Your Day For Number is : " + arr[num] + "day");
				} catch(ArrayIndexOutOfBoundsException a) {
					System.out.println("Please Enter Within 0-6 , Number you Enter is " + num);
				}	
		
			}
		}