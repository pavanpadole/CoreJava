/*49. Create Interface Taxable with members salesTax=7% and incomeTax=10.5%. create abstract method calcTax(). a. Create class Employee(empId,name,salary)
  and implement Taxable to calculate incomeTax on yearly salary. b. Create class Product(pid,price,quantity) and implement Taxable to calculate 
  salesTax on unit price of product. c. Create class for main method(Say XYZ), accept employee information and a product information from user and 
  print income tax and sales tax respectively.
*/

import java.util.Scanner;
interface Taxable{

     int salesTax = 7;
     double incomeTax = 10.5;

     public abstract void calcTax();
}


class Employee implements Taxable{
    int empId;
    String name;
    double salary;
    double incomeTax = 10.5;   // 10.5%


   public void calcTax(){
    System.out.println("Enter employee details:empid , name and salary");
        Scanner sc = new Scanner(System.in);
        int empId = sc.nextInt();
        String name = sc.next();
        double salary = sc.nextDouble();
        this.incomeTax = incomeTax;

        double incomeTax1 = (incomeTax/100) * salary;

        System.out.println("yearly incometax = "+incomeTax1);

    }

}
class Product implements Taxable{

    int pid;
    double price;
    int quantity;
    int salesTax = 7;
    
    public void calcTax(){
    System.out.println("Enter product details: pid , price and quantity ");
    Scanner sc1 = new Scanner(System.in);
    int pid = sc1.nextInt();
    double price = sc1.nextDouble();
    int quantity = sc1.nextInt();
    this.salesTax = salesTax;

    double salesTax1 = (price * salesTax)/100;

    System.out.println("Total sales tax =" + salesTax1);

        }

}

class Q49_XYZ{

    public static void main(String args[]){
     Employee e = new Employee();
     e.calcTax();

     Product p = new Product();
     p.calcTax();      

    }
}