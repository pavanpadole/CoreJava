/* 45.	Create a class Student with two members : rollno and percentage. Create default and parameterized constructors. Create method show() to display information.
 Create another class CollegeStudent inherits Student class. Add a new member semester to it. Create default and parameterized constructors.
 Also override show() method that calls super class show() method and displays semester. Create another class SchoolStudent inherits Student class.
 Add a new member className(eg 12th ,10th etc.) to it. Create default and parameterized constructors. Also override show() method that calls 
 super class show() method and displays className. Create a class( say Demo) with main method that carries out the operation of the project : -- 
 :- has array to store objects of any class(Student,  CollegeStudent or SchoolStudent)
 --create two CollegeStudent  and three SchoolStudent objects and store them inside the array 
 -- display all records from the array 
 -- search record on the basic of rollno and check given rollno is of SchoolStudent or of CollegeStudent.
 --count how many students are having A grade, if for A grade percentage >75. 
 
*/

import java.util.*;
class Student{
	int rollno ;
	double percentage;
	Student(){
		this(20,65.5);
	}
	Student(int no , double Per)
	{
		rollno = no;
		percentage = Per;
	}
	void show()
	{
		System.out.println(" Rollno : " + rollno + "   Percentage : " + percentage);	
	}
}

class CollegeStudent extends Student{
	CollegeStudent(){
		this(21,70);
	}
	CollegeStudent(int no , double per){
		super(no,per);
	}
	void semester() {
		System.out.println("College Student");
	}
	void show() {
		super.show();
		semester();
	}
}

class SchoolStudent extends Student{
	SchoolStudent(){
		this(23,80);
	}
	SchoolStudent(int no , double per){
		super(no,per);
	}
	void class10() {
		System.out.println("School Student");
	}
	void show() {
		super.show();
		class10();
	}
}


public class Q45_Demo {
	public static void main(String[] args) {
		CollegeStudent  c1 = new CollegeStudent();
		CollegeStudent c2 = new CollegeStudent(2,60);
		
		SchoolStudent s1 = new SchoolStudent();
		SchoolStudent s2 = new SchoolStudent(3,88.6);
		SchoolStudent s3 = new SchoolStudent(4,90.8);
		
		Student[] arr = {c1,c2,s1,s2,s3};
		
		// display
		int Acount=0;
		for(Student s : arr)
		{
			s.show();
			if(s.percentage > 75)	
				Acount++;
		}
		
		System.out.println("\n\nEnter Roll Number To Search ");
			Scanner scan = new Scanner(System.in);
			int number = scan.nextInt();
			for(Student s : arr)
			{
				if(s.rollno == number)
				{
					s.show();
					break;	
				}			
			}
		
		System.out.println(" Number OF Student Score A grade : " + Acount);
	}
}