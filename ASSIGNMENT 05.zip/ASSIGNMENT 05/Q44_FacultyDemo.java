/* 44.	Create three classes
-	Faculty with two data members facultyId and salary and two methods, one intput() method for accepting facultyId as input and another printSalary() to print salary.
-	FullTimeFaculty that inherits class Faculty with two data members’ basicSalary and allowance. Override input() method in this class that calls super class inut() method and accepts basicSalary and allowance as input. Salary should not be accepted as input but should be calculated using formula (basicSalary + allowance)
-	PartTimeFaculty that inherits class Faculty with two data members’ workingHours, ratePerHour. Override input() method in this class that calls super class inut() method and accepts workingHours and ratePerHour as input. Salary should not be accepted as input but should be calculated using formula ( workingHour * ratePerHour )

*/

import java.lang.*;
import java.util.*;
class Faculty{
		int facultyId ;
		double salary;
		
		void input() {
			Scanner scan = new Scanner(System.in);
			System.out.println("Enter Id For Faculty");
			facultyId = scan.nextInt();
		}
		
		void printSalary() {
			System.out.println("Faculty Id : " +   facultyId + "    Salary : "+ salary);
		}	
	}
	
	class FullTimeFaculty extends Faculty{
		int basicSalary , allowance;
		
		 FullTimeFaculty(){
			 this.input();
		 }
		void input() {
			super.input();
			Scanner scan = new Scanner(System.in);
			System.out.println("Enter Basic Salary");
			this.basicSalary = scan.nextInt();
			System.out.println("Enter Allowance ");
			this.allowance = scan.nextInt();
			super.salary = this.basicSalary + this.allowance;
		}
	}
	
	class PartTimeFaculty extends Faculty{
		int workingHour , ratePerHour;
		PartTimeFaculty(){
			this.input();
		}
		void input() {
			super.input();
			Scanner scan = new Scanner(System.in);
			System.out.println("Enter Working Hour");
			this.workingHour = scan.nextInt();
			System.out.println("Enter Rate Per Hour ");
			this.ratePerHour = scan.nextInt();
			super.salary = this.workingHour*this.ratePerHour;
		
		}
	}
	
	
	public class Q44_FacultyDemo{
		public static void main(String[] args) {
			FullTimeFaculty f1 = new FullTimeFaculty();
			PartTimeFaculty p1 = new PartTimeFaculty();
			
			f1.printSalary();
			p1.printSalary();
		}
	}
	